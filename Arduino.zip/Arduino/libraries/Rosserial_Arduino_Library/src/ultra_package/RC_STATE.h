#ifndef _ROS_ultra_package_RC_STATE_h
#define _ROS_ultra_package_RC_STATE_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace ultra_package
{

  class RC_STATE : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      uint16_t rxChannels[16];

    RC_STATE():
      header(),
      rxChannels()
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      for( uint32_t i = 0; i < 16; i++){
      *(outbuffer + offset + 0) = (this->rxChannels[i] >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->rxChannels[i] >> (8 * 1)) & 0xFF;
      offset += sizeof(this->rxChannels[i]);
      }
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      for( uint32_t i = 0; i < 16; i++){
      this->rxChannels[i] =  ((uint16_t) (*(inbuffer + offset)));
      this->rxChannels[i] |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->rxChannels[i]);
      }
     return offset;
    }

    virtual const char * getType() override { return "ultra_package/RC_STATE"; };
    virtual const char * getMD5() override { return "12cd8f6db76593b364dee8318211d1f3"; };

  };

}
#endif
