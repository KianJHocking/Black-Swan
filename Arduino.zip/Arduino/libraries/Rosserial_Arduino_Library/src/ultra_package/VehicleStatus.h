#ifndef _ROS_ultra_package_VehicleStatus_h
#define _ROS_ultra_package_VehicleStatus_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"
#include "std_msgs/Header.h"

namespace ultra_package
{

  class VehicleStatus : public ros::Msg
  {
    public:
      typedef std_msgs::Header _header_type;
      _header_type header;
      typedef bool _armed_type;
      _armed_type armed;
      typedef bool _log_type;
      _log_type log;
      typedef bool _lights_type;
      _lights_type lights;
      typedef bool _relay1_type;
      _relay1_type relay1;
      typedef bool _relay2_type;
      _relay2_type relay2;
      typedef bool _relay3_type;
      _relay3_type relay3;
      typedef bool _relay4_type;
      _relay4_type relay4;
      typedef uint8_t _hdmi_type;
      _hdmi_type hdmi;

    VehicleStatus():
      header(),
      armed(0),
      log(0),
      lights(0),
      relay1(0),
      relay2(0),
      relay3(0),
      relay4(0),
      hdmi(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      offset += this->header.serialize(outbuffer + offset);
      union {
        bool real;
        uint8_t base;
      } u_armed;
      u_armed.real = this->armed;
      *(outbuffer + offset + 0) = (u_armed.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->armed);
      union {
        bool real;
        uint8_t base;
      } u_log;
      u_log.real = this->log;
      *(outbuffer + offset + 0) = (u_log.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->log);
      union {
        bool real;
        uint8_t base;
      } u_lights;
      u_lights.real = this->lights;
      *(outbuffer + offset + 0) = (u_lights.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->lights);
      union {
        bool real;
        uint8_t base;
      } u_relay1;
      u_relay1.real = this->relay1;
      *(outbuffer + offset + 0) = (u_relay1.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->relay1);
      union {
        bool real;
        uint8_t base;
      } u_relay2;
      u_relay2.real = this->relay2;
      *(outbuffer + offset + 0) = (u_relay2.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->relay2);
      union {
        bool real;
        uint8_t base;
      } u_relay3;
      u_relay3.real = this->relay3;
      *(outbuffer + offset + 0) = (u_relay3.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->relay3);
      union {
        bool real;
        uint8_t base;
      } u_relay4;
      u_relay4.real = this->relay4;
      *(outbuffer + offset + 0) = (u_relay4.base >> (8 * 0)) & 0xFF;
      offset += sizeof(this->relay4);
      *(outbuffer + offset + 0) = (this->hdmi >> (8 * 0)) & 0xFF;
      offset += sizeof(this->hdmi);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      offset += this->header.deserialize(inbuffer + offset);
      union {
        bool real;
        uint8_t base;
      } u_armed;
      u_armed.base = 0;
      u_armed.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->armed = u_armed.real;
      offset += sizeof(this->armed);
      union {
        bool real;
        uint8_t base;
      } u_log;
      u_log.base = 0;
      u_log.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->log = u_log.real;
      offset += sizeof(this->log);
      union {
        bool real;
        uint8_t base;
      } u_lights;
      u_lights.base = 0;
      u_lights.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->lights = u_lights.real;
      offset += sizeof(this->lights);
      union {
        bool real;
        uint8_t base;
      } u_relay1;
      u_relay1.base = 0;
      u_relay1.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->relay1 = u_relay1.real;
      offset += sizeof(this->relay1);
      union {
        bool real;
        uint8_t base;
      } u_relay2;
      u_relay2.base = 0;
      u_relay2.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->relay2 = u_relay2.real;
      offset += sizeof(this->relay2);
      union {
        bool real;
        uint8_t base;
      } u_relay3;
      u_relay3.base = 0;
      u_relay3.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->relay3 = u_relay3.real;
      offset += sizeof(this->relay3);
      union {
        bool real;
        uint8_t base;
      } u_relay4;
      u_relay4.base = 0;
      u_relay4.base |= ((uint8_t) (*(inbuffer + offset + 0))) << (8 * 0);
      this->relay4 = u_relay4.real;
      offset += sizeof(this->relay4);
      this->hdmi =  ((uint8_t) (*(inbuffer + offset)));
      offset += sizeof(this->hdmi);
     return offset;
    }

    virtual const char * getType() override { return "ultra_package/VehicleStatus"; };
    virtual const char * getMD5() override { return "31796bc665b592dbdaf695fdf3ffb607"; };

  };

}
#endif
