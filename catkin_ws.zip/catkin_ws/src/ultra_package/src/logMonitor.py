#!/usr/bin/env python3
import rospy
from ultra_package.msg import RC_STATE
import sys
import time
import serial
 
ser = serial.Serial(
        port = rospy.get_param('/log/port'),
        baudrate = 9600,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS,
        timeout=1
)

lastTime = 0

def callbackRC(msg):
    global lastTime
    if (msg.rxChannels[6] < 1250):
    	serString = "<LOG,1>"
    else:
    	serString = "<LOG,0>"
    if (time.time() - lastTime > 0.2):
        ser.write(str.encode(serString))
    	
rospy.Subscriber("/rx_pwm", RC_STATE, callbackRC)

def main(args):
    rospy.init_node('logMonitor', anonymous=True)
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
        
if __name__ == '__main__':
    main(sys.argv)
