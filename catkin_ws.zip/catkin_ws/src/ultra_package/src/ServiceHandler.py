#!/usr/bin/env python3
import rospy
import sys
from mavros_msgs.srv import CommandBool
from mavros_msgs.srv import SetMode
from ultra_package.msg import RC_STATE

class ServiceHandler:

    def __init__(self):
        self.armService = rospy.ServiceProxy('/mavros/cmd/arming', CommandBool)
        self.modeService = rospy.ServiceProxy('/mavros/set_mode', SetMode)
        rospy.Subscriber("/rx_pwm", RC_STATE, self.callbackRC)
        self.armed = False
        self.mode = 1
        
    def callbackRC(self, data):
        if ((data.rxChannels[4] > 1750) and (self.armed == False)):
            if(self.armService(value = True)):
                self.armed = True
        elif ((data.rxChannels[4] < 1250) and (self.armed == True)):
            if(self.armService(value = False)):
                self.armed = False
        if ((data.rxChannels[5] < 1250) and (self.mode != 1)):
            self.mode = 1
            self.modeService(custom_mode = "MANUAL")
    #    elif ((data.rxChannels[5] < 1750) and (self.mode !=2)):
   #         self.modeService(custom_moe = "NAME")  
        elif ((data.rxChannels[5] > 1750) and (self.mode != 3)):
            self.mode = 3
            self.modeService(custom_mode = "STABILIZE")
            
            

def main(args):
    rospy.init_node('ServiceHandlerNode', anonymous=True)
    handler = ServiceHandler()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
        
if __name__ == '__main__':
    main(sys.argv)
