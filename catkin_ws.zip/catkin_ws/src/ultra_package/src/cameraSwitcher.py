#!/usr/bin/env python3
import rospy
from std_msgs.msg import Int8
from ultra_package.msg import RC_STATE
import time
import sys
    	
def mainLoop():
    pub = rospy.Publisher("/avCamera", Int8, queue_size=10)
    lastTime = 0
    i = 0
    while True:
        now = time.time()
        if (now - lastTime) > 3:
            print(i)
            lastTime = now
            pub.publish(i)
            if i > 3:
                i = 0
            else:
                i = i + 1    
       
       
class MavController:

    def __init__(self):
        self.rx = [0, 0]
        self.lastRx = [0, 0] # -1 for left, 0 for middle, 1 for right (on X3 H16 dpad)
        self.currentCamera = 1
        self.pub = rospy.Publisher('/avCamera', Int8, queue_size=10)
        rospy.Subscriber("/rx_pwm", RC_STATE, self.callbackRC)
        rospy.init_node('avState', anonymous=True)

    def callbackRC(self, data):
        if data.rxChannels[6] > 1750:
            self.rx[0] = 1
        elif data.rxChannels[6] < 1250:
            self.rx[0] = -1
        else:
            self.rx[0] = 0
            
        if data.rxChannels[5] > 1750:
            self.rx[1] = 1
        elif data.rxChannels[5] < 1250:
            self.rx[1] = -1
        else:
            self.rx[1] = 0
        
        if self.rx != self.lastRx:
            self.lastRX = self.rx
            if self.rx == [0, 1]:
            	self.currentCamera = 1
            elif self.rx == [1, 0]:
            	self.currentCamera = 2
            elif self.rx == [0, -1]:
            	self.currentCamera = 3
            elif self.rx == [-1, 0]:
            	self.currentCamera = 4
            self.pub.publish(self.currentCamera)

if __name__ == '__main__':
    mc = MavController()
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
        
