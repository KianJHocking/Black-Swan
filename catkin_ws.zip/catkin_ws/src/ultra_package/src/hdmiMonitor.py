#!/usr/bin/env python3
import rospy
from ultra_package.msg import RC_STATE
import sys
import time

import serial
 
ser = serial.Serial(
        port = rospy.get_param('/hdmi/port'),
        baudrate = 9600,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        bytesize=serial.EIGHTBITS,
        timeout=1
)

hdmi = 1
prevHDMI = 1

def callbackRC(msg):
    global hdmi, prevHDMI
    if (msg.rxChannels[7] > 1750):
        hdmi = 1
    elif (msg.rxChannels[7] < 1250):
        hdmi = 2
    else:
        hdmi = 3
    if hdmi != prevHDMI:  
        hdmiString = "port" + str(hdmi - 1) + "R"  
        ser.write(str.encode(hdmiString))
    prevHDMI = hdmi
    	
rospy.Subscriber("/rx_pwm", RC_STATE, callbackRC)

def main(args):
    rospy.init_node('hdmiMonitor', anonymous=True)
    try:
        rospy.spin()
    except KeyboardInterrupt:
        print("Shutting down")
        
if __name__ == '__main__':
    main(sys.argv)
