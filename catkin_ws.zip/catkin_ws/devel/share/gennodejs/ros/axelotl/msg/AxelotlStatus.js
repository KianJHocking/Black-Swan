// Auto-generated. Do not edit!

// (in-package axelotl.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class AxelotlStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.land = null;
      this.water = null;
      this.armed = null;
      this.log = null;
      this.bilge = null;
      this.lights = null;
      this.reset = null;
      this.relay1 = null;
      this.relay2 = null;
      this.relay3 = null;
      this.relay4 = null;
      this.relay5 = null;
      this.voltage = null;
      this.hdmi = null;
    }
    else {
      if (initObj.hasOwnProperty('land')) {
        this.land = initObj.land
      }
      else {
        this.land = false;
      }
      if (initObj.hasOwnProperty('water')) {
        this.water = initObj.water
      }
      else {
        this.water = false;
      }
      if (initObj.hasOwnProperty('armed')) {
        this.armed = initObj.armed
      }
      else {
        this.armed = false;
      }
      if (initObj.hasOwnProperty('log')) {
        this.log = initObj.log
      }
      else {
        this.log = false;
      }
      if (initObj.hasOwnProperty('bilge')) {
        this.bilge = initObj.bilge
      }
      else {
        this.bilge = false;
      }
      if (initObj.hasOwnProperty('lights')) {
        this.lights = initObj.lights
      }
      else {
        this.lights = false;
      }
      if (initObj.hasOwnProperty('reset')) {
        this.reset = initObj.reset
      }
      else {
        this.reset = false;
      }
      if (initObj.hasOwnProperty('relay1')) {
        this.relay1 = initObj.relay1
      }
      else {
        this.relay1 = false;
      }
      if (initObj.hasOwnProperty('relay2')) {
        this.relay2 = initObj.relay2
      }
      else {
        this.relay2 = false;
      }
      if (initObj.hasOwnProperty('relay3')) {
        this.relay3 = initObj.relay3
      }
      else {
        this.relay3 = false;
      }
      if (initObj.hasOwnProperty('relay4')) {
        this.relay4 = initObj.relay4
      }
      else {
        this.relay4 = false;
      }
      if (initObj.hasOwnProperty('relay5')) {
        this.relay5 = initObj.relay5
      }
      else {
        this.relay5 = false;
      }
      if (initObj.hasOwnProperty('voltage')) {
        this.voltage = initObj.voltage
      }
      else {
        this.voltage = 0.0;
      }
      if (initObj.hasOwnProperty('hdmi')) {
        this.hdmi = initObj.hdmi
      }
      else {
        this.hdmi = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AxelotlStatus
    // Serialize message field [land]
    bufferOffset = _serializer.bool(obj.land, buffer, bufferOffset);
    // Serialize message field [water]
    bufferOffset = _serializer.bool(obj.water, buffer, bufferOffset);
    // Serialize message field [armed]
    bufferOffset = _serializer.bool(obj.armed, buffer, bufferOffset);
    // Serialize message field [log]
    bufferOffset = _serializer.bool(obj.log, buffer, bufferOffset);
    // Serialize message field [bilge]
    bufferOffset = _serializer.bool(obj.bilge, buffer, bufferOffset);
    // Serialize message field [lights]
    bufferOffset = _serializer.bool(obj.lights, buffer, bufferOffset);
    // Serialize message field [reset]
    bufferOffset = _serializer.bool(obj.reset, buffer, bufferOffset);
    // Serialize message field [relay1]
    bufferOffset = _serializer.bool(obj.relay1, buffer, bufferOffset);
    // Serialize message field [relay2]
    bufferOffset = _serializer.bool(obj.relay2, buffer, bufferOffset);
    // Serialize message field [relay3]
    bufferOffset = _serializer.bool(obj.relay3, buffer, bufferOffset);
    // Serialize message field [relay4]
    bufferOffset = _serializer.bool(obj.relay4, buffer, bufferOffset);
    // Serialize message field [relay5]
    bufferOffset = _serializer.bool(obj.relay5, buffer, bufferOffset);
    // Serialize message field [voltage]
    bufferOffset = _serializer.float32(obj.voltage, buffer, bufferOffset);
    // Serialize message field [hdmi]
    bufferOffset = _serializer.uint8(obj.hdmi, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AxelotlStatus
    let len;
    let data = new AxelotlStatus(null);
    // Deserialize message field [land]
    data.land = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [water]
    data.water = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [armed]
    data.armed = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [log]
    data.log = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [bilge]
    data.bilge = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [lights]
    data.lights = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [reset]
    data.reset = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [relay1]
    data.relay1 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [relay2]
    data.relay2 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [relay3]
    data.relay3 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [relay4]
    data.relay4 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [relay5]
    data.relay5 = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [voltage]
    data.voltage = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [hdmi]
    data.hdmi = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'axelotl/AxelotlStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'df37937c57ab21f7ffd15297e7333ec5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Vehicle Relay and Modes Status
    
    bool land
    bool water
    bool armed
    bool log
    bool bilge
    bool lights
    bool reset
    bool relay1
    bool relay2
    bool relay3
    bool relay4
    bool relay5
    float32 voltage
    uint8 hdmi
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AxelotlStatus(null);
    if (msg.land !== undefined) {
      resolved.land = msg.land;
    }
    else {
      resolved.land = false
    }

    if (msg.water !== undefined) {
      resolved.water = msg.water;
    }
    else {
      resolved.water = false
    }

    if (msg.armed !== undefined) {
      resolved.armed = msg.armed;
    }
    else {
      resolved.armed = false
    }

    if (msg.log !== undefined) {
      resolved.log = msg.log;
    }
    else {
      resolved.log = false
    }

    if (msg.bilge !== undefined) {
      resolved.bilge = msg.bilge;
    }
    else {
      resolved.bilge = false
    }

    if (msg.lights !== undefined) {
      resolved.lights = msg.lights;
    }
    else {
      resolved.lights = false
    }

    if (msg.reset !== undefined) {
      resolved.reset = msg.reset;
    }
    else {
      resolved.reset = false
    }

    if (msg.relay1 !== undefined) {
      resolved.relay1 = msg.relay1;
    }
    else {
      resolved.relay1 = false
    }

    if (msg.relay2 !== undefined) {
      resolved.relay2 = msg.relay2;
    }
    else {
      resolved.relay2 = false
    }

    if (msg.relay3 !== undefined) {
      resolved.relay3 = msg.relay3;
    }
    else {
      resolved.relay3 = false
    }

    if (msg.relay4 !== undefined) {
      resolved.relay4 = msg.relay4;
    }
    else {
      resolved.relay4 = false
    }

    if (msg.relay5 !== undefined) {
      resolved.relay5 = msg.relay5;
    }
    else {
      resolved.relay5 = false
    }

    if (msg.voltage !== undefined) {
      resolved.voltage = msg.voltage;
    }
    else {
      resolved.voltage = 0.0
    }

    if (msg.hdmi !== undefined) {
      resolved.hdmi = msg.hdmi;
    }
    else {
      resolved.hdmi = 0
    }

    return resolved;
    }
};

module.exports = AxelotlStatus;
