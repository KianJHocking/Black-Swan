
"use strict";

let AxelotlStatus = require('./AxelotlStatus.js');

module.exports = {
  AxelotlStatus: AxelotlStatus,
};
